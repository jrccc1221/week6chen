
let members = ["Mary","Sam","Joey","Paul","Mike","Char","Jenny","Kennedy","Kaden","Kurt","Anne"]
btnEnter.onclick=function(in_list){
  if
  (members.includes(inptMem.value)){
    lblName.textContent = "You are a member."
    } else {
    members.push(inptMem.value)
    lblName.textContent = "You are not a member."
    }
}



